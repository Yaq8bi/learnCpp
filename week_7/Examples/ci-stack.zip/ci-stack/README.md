[![Stack](https://github.com/iustmehri/ci-stack/actions/workflows/stack.yml/badge.svg?branch=main)](https://github.com/iustmehri/ci-stack/actions/workflows/stack.yml)

# Stack

## Using TDD and Googletest Develop and Test a Stack class
