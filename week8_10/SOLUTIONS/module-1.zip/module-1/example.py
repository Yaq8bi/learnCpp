#!/usr/bin/env python3

import module

module.function("Linda", 32)
